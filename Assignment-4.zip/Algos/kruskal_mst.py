class DisjointSet:
    #Initializes the disjoint set with each vertices in its own set.
    def __init__(self, vertices):
        
        #Creating a disjoint set where each vertex is its own parent initially.
        self.parent = {vertex: vertex for vertex in vertices}
        #Initializin the rank of each vertex as 0.
        self.rank = {vertex: 0 for vertex in vertices}

    def find(self, vertex):
        #Finds the root of the set that a vertex belongs to.
        
        #Recursive function to find the root parent of a vertex with the path compression.
        if self.parent[vertex] != vertex:
            self.parent[vertex] = self.find(self.parent[vertex])
        return self.parent[vertex]

    def union(self, vertex1, vertex2):
        #Merges two sets that the vertex belongs to.
       
        #Finding the root parents of the sets that vertex1 and vertex2 belongs to
        root1 = self.find(vertex1)
        root2 = self.find(vertex2)

        if root1 != root2:
            #Union by rank: Attaching the set with lower rank to the one with higher rank
            if self.rank[root1] < self.rank[root2]:
                self.parent[root1] = root2
            elif self.rank[root1] > self.rank[root2]:
                self.parent[root2] = root1
            else:
            #If the ranks are equal, attach one set to the other and increment rank.
                self.parent[root2] = root1
                self.rank[root1] += 1

def kruskal_mst(graph):

    #Calculates the minimum spanning tree (MST) of a graph using Kruskal's algorithm.
    #Each tuple is an edge in the MST and contains (start_vertex, end_vertex, weight).
    
    #Determine the total number of vertices in the graph by calculating the length of the graph list.
    #this values represents the total number of vertices present in the given graph structure.
    num_vertices = len(graph) 
    
    # Initialize an empty list named 'edges'.
    # This list will store the edges extracted from the graph's adjacency matrix to be used in Kruskal's algorithm.
    edges = []

    #Extracting all edges from the adjacency matrix
    #graph (list of lists): A graph represented as an adjacency matrix.
    for i in range(num_vertices):
        for j in range(i + 1, num_vertices):  # To avoid duplicate edges
            if graph[i][j] is not None and graph[i][j] != float('inf'):
                edges.append((graph[i][j], i, j))

    # Sorting edges based on weight
    edges.sort(key=lambda x: x[0])

    # Initialize disjoint sets for each vertices
    ds = DisjointSet(range(num_vertices))
    mst = []

    # Iterate through sorted edges and add them to MST if they don't form a cycle
    for weight, start, end in edges:
        if ds.find(start) != ds.find(end):
            ds.union(start, end)
            mst.append((start, end, weight))

    return mst

#graph with the input of edges by using adjacency matrix
graph = [
    [None, 4, None, None, None, None, None, 8, None],
    [4, None, 8, None, None, None, None, 11, None],
    [None, 8, None, 7, None, 4, None, None, 2],
    [None, None, 7, None, 9, 14, None, None, None],
    [None, None, None, 9, None, 10, None, None, None],
    [None, None, 4, 14, 10, None, 2, None, None],
    [None, None, None, None, None, 2, None, 1, 6],
    [8, 11, None, None, None, None, 1, None, 7],
    [None, None, 2, None, None, None, 6, 7, None]
]

#computing and calculating the total weight of the minimum spanning tree
minimum_spanning_tree = kruskal_mst(graph) #Finding the minimum spanning tree
total_weight = sum(edge[2] for edge in minimum_spanning_tree) #calculating the total weight of Minimum spanning tree edges 
print("Total weight of minimum spannning tree:", total_weight) #Dislpays the total weight of the Minimum spanning tree.
print("Minimum spanning tree for kruskal_mst(graph):", minimum_spanning_tree) #displays the minimum spanning tree edges. 