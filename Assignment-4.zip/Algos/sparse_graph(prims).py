import heapq

def prim_mst(graph): #Function that calculates the miinimum spanning tree by using the prims algorithm
    
    #A graph represented as an adjacency matrix where
    #graph[i][j] represents the weight of the edge between vertices i and j. If there's no edge, it's represented by None.
    #list of tuples: The MST represented as a list of tuples (start_vertex, end_vertex, weight).
    
    num_vertices = len(graph)  # Number of vertices in the graph
    if num_vertices == 0:
        return [] #returns the empty list to store the edges of minimum spanning tree.

    mst = []  # Initialize the list to store the edges of the MST
    start_vertex = 0  # Start the algorithm from the first vertex (index 0)
    visited = set([start_vertex])  # A set to keep track of visited vertices

    # Initialize a priority queue (min heap) to store edges with their weights
    # Only include edges that are present (graph[start_vertex][j] is not None)
    edges = [(graph[start_vertex][j], start_vertex, j) for j in range(num_vertices) if graph[start_vertex][j] is not None]
    heapq.heapify(edges)

    # Main loop to construct the MST
    while len(visited) < num_vertices and edges: #continues the algorithm while there are unvisited vertices and available edges.
        weight, frm, to = heapq.heappop(edges)  # Select the edge with the minimum weight
        if to not in visited: #checking the ending vertex 
            visited.add(to)  # Mark the vertex as visited
            mst.append((frm, to, weight))  # Add the edge to the MST

            # Add new edges to the priority queue from the newly added vertex
            for next_vertex in range(num_vertices):
                if next_vertex not in visited and graph[to][next_vertex] is not None:
                    heapq.heappush(edges, (graph[to][next_vertex], to, next_vertex))

    return mst # returns the list of tuples representing the minimum spanning tree edges.

# Sparse Graph with 14 nodes (few of the edges compared to nodes): 
sparse_graph = [
    # Input of a sparse graph represented as an adjacency matrix
    # Nodes have connections with a few other nodes (few edges compared to nodes)

    [None, 5, None, None, None, None, None, None, None, None, None, None, None, None],
    [5, None, 6, None, None, None, None, None, None, None, None, None, None, None],
    [None, 6, None, 7, None, None, None, None, None, None, None, None, None, None],
    [None, None, 7, None, 8, None, None, None, None, None, None, None, None, None],
    [None, None, None, 8, None, 9, None, None, None, None, None, None, None, None],
    [None, None, None, None, 9, None, 10, None, None, None, None, None, None, None],
    [None, None, None, None, None, 10, None, 11, None, None, None, None, None, None],
    [None, None, None, None, None, None, 11, None, 12, None, None, None, None, None],
    [None, None, None, None, None, None, None, 12, None, 13, None, None, None, None],
    [None, None, None, None, None, None, None, None, 13, None, 14, None, None, None],
    [None, None, None, None, None, None, None, None, None, 14, None, 15, None, None],
    [None, None, None, None, None, None, None, None, None, None, 15, None, 16, None],
    [None, None, None, None, None, None, None, None, None, None, None, 16, None, 17],
    [None, None, None, None, None, None, None, None, None, None, None, None, 17, None]
]

#computing and calculating the total weight of the minimum spanning tree
minimum_spanning_tree = prim_mst(sparse_graph) #Finding the minimum spanning tree
total_weight = sum(edge[2] for edge in minimum_spanning_tree) #calculates the total weight of an minimum spanning tree nodes.
print("Total weight of minimum spannning tree:", total_weight) #displays the total weight of an minimum spanning tree
print("Minimum spanning tree for prim_mst(sparse_graph):", minimum_spanning_tree) #displaying the minimum spanning tree nodes.