import heapq
#importing the heapq module to utilize the priority queues of min heap for ethe edge selections.
def prim_mst(graph): #prim_mst will calculates the minimum spanning tree of a graph by using the prim's algorithm.

    num_vertices = len(graph)  # Number of vertices in the graph.
    if num_vertices == 0:
        return []

    mst = []  # Initialize the list to store the edges of the MST.
    start_vertex = 0  # Start the algorithm from the first vertex (index 0).
    visited = set([start_vertex])  # A set to keep track of visited vertices.

    #Initialize a priority queue (min heap) to store edges with their weights.
    #The MST represented as a list of tuples (start_vertex, end_vertex, weight).
    #Only include edges that are present (graph[start_vertex][j] is not None).
    #The graph is represented as an adjacnecy matrix where graph[i][j] represents the weight of the edge between vertices i and j. 
    #If there's no edge, it's represented by None.

    edges = [(graph[start_vertex][j], start_vertex, j) for j in range(num_vertices) if graph[start_vertex][j] is not None]
    heapq.heapify(edges) #transforms a list into a heap in linear time and the edges list becomes a min heap and ensuring the edge with the
    #smallest weight is at the root of the heap.

    # Main loop to construct the MST
    while len(visited) < num_vertices and edges:
        weight, frm, to = heapq.heappop(edges)  # Select the edge with the minimum weight
        if to not in visited:
            visited.add(to)  # Mark the vertex as visited
            mst.append((frm, to, weight))  # Add the edge to the MST

            # Add new edges to the priority queue from the newly added vertex
            for next_vertex in range(num_vertices):
                if next_vertex not in visited and graph[to][next_vertex] is not None:
                    heapq.heappush(edges, (graph[to][next_vertex], to, next_vertex))

    return mst #returns the minimum spanning tree.

#graph with the following vertices and edges
graph = [
    [0, 2, None, 6, None, None, None],
    [2, 0, 3, 8, 5, None, None],
    [None, 3, 0, None, 7, None, None],
    [6, 8, None, 0, 9, 4, None],
    [None, 5, 7, 9, 0, None, 1],
    [None, None, None, 4, None, 0, 2],
    [None, None, None, None, 1, 2, 0]
]

#computing and calculating the total weight of the minimum spanning tree
minimum_spanning_tree = prim_mst(graph) #Calculating the minimum spanning tree by using prim's algorithm.
total_weight = sum(edge[2] for edge in minimum_spanning_tree) #calculates the total weight of the Minimum spanning tree.
print("Total weight of minimum spannning tree:", total_weight) #This displays the total weight of the minimum spanning tree.
print("Minimum spanning tree for prim_mst(graph):", minimum_spanning_tree) #This will displays the minimum spanning tree with the edges. 