class DisjointSet:
    def __init__(self, vertices):
        """
        Initializes the disjoint set with each vertex in its own set.
        """
        self.parent = {vertex: vertex for vertex in vertices}
        self.rank = {vertex: 0 for vertex in vertices}

    def find(self, vertex):
        """
        Finds the root of the set that a vertex belongs to.
        """
        if self.parent[vertex] != vertex:
            self.parent[vertex] = self.find(self.parent[vertex])
        return self.parent[vertex]

    def union(self, vertex1, vertex2):
        """
        Merges two sets that the vertices belong to.
        """
        root1 = self.find(vertex1)
        root2 = self.find(vertex2)

        if root1 != root2:
            if self.rank[root1] < self.rank[root2]:
                self.parent[root1] = root2
            elif self.rank[root1] > self.rank[root2]:
                self.parent[root2] = root1
            else:
                self.parent[root2] = root1
                self.rank[root1] += 1

def kruskal_mst(graph):
    """
    Computes the minimum spanning tree (MST) of a graph using Kruskal's algorithm.

    Parameters:
    graph (list of lists): A graph represented as an adjacency matrix.

    Returns:
    list of tuples: Each tuple is an edge in the MST and contains (start_vertex, end_vertex, weight).
    """
    num_vertices = len(graph)
    edges = []

    # Extracting all edges from the adjacency matrix
    for i in range(num_vertices):
        for j in range(i + 1, num_vertices):  # To avoid duplicate edges
            if graph[i][j] is not None and graph[i][j] != float('inf'):
                edges.append((graph[i][j], i, j))

    # Sorting edges based on weight
    edges.sort(key=lambda x: x[0])

    # Initialize disjoint sets for each vertex
    ds = DisjointSet(range(num_vertices))
    mst = []

    # Iterate through sorted edges and add them to MST if they don't form a cycle
    for weight, start, end in edges:
        if ds.find(start) != ds.find(end):
            ds.union(start, end)
            mst.append((start, end, weight))

    return mst

# # Dense Graph with 14 nodes (more edges, closer to complete graph) with an adjacency matrix
dense_graph = [
    [None, 5, 9, 2, 4, 1, 6, 7, 10, 8, 12, 3, 2, 4],
    [5, None, 3, 6, 7, 9, 8, 10, 2, 11, 5, 4, 2, 5],
    [9, 3, None, 1, 5, 8, 9, 4, 6, 7, 3, 5, 7, 1],
    [2, 6, 1, None, 9, 7, 5, 3, 4, 6, 2, 8, 1, 7],
    [4, 7, 5, 9, None, 6, 4, 2, 3, 5, 9, 7, 3, 6],
    [1, 9, 8, 7, 6, None, 2, 5, 7, 8, 4, 6, 9, 1],
    [6, 8, 9, 5, 4, 2, None, 1, 3, 2, 9, 7, 8, 3],
    [7, 10, 4, 3, 2, 5, 1, None, 6, 4, 5, 3, 2, 9],
    [10, 2, 6, 4, 3, 7, 3, 6, None, 1, 8, 2, 4, 5],
    [8, 11, 7, 6, 5, 8, 2, 4, 1, None, 7, 6, 3, 2],
    [12, 5, 3, 2, 9, 4, 9, 5, 8, 7, None, 1, 6, 4],
    [3, 4, 5, 8, 7, 6, 7, 3, 2, 6, 1, None, 5, 8],
    [2, 2, 7, 1, 3, 9, 8, 2, 4, 3, 6, 5, None, 7],
    [4, 5, 1, 7, 6, 1, 3, 9, 5, 2, 4, 8, 7, None]
]

#computing and calculating the total weight of the minimum spanning tree
minimum_spanning_tree = kruskal_mst(dense_graph)
total_weight = sum(edge[2] for edge in minimum_spanning_tree)
print("Total weight of minimum spannning tree:", total_weight)
print("Minimum spanning tree for Kruskal_mst(dense_graph):", minimum_spanning_tree)


