import random
import time
import heapq
import matplotlib.pyplot as plt

class DisjointSet:
    def __init__(self, vertices):
        self.parent = {vertex: vertex for vertex in vertices}
        self.rank = {vertex: 0 for vertex in vertices}

    def find(self, vertex):
        if self.parent[vertex] != vertex:
            self.parent[vertex] = self.find(self.parent[vertex])
        return self.parent[vertex]

    def union(self, vertex1, vertex2):
        root1 = self.find(vertex1)
        root2 = self.find(vertex2)

        if root1 != root2:
            if self.rank[root1] < self.rank[root2]:
                self.parent[root1] = root2
            elif self.rank[root1] > self.rank[root2]:
                self.parent[root2] = root1
            else:
                self.parent[root2] = root1
                self.rank[root1] += 1

def generate_graph_negative(num_vertices, edge_density, weight_range):
    graph = [[0 if i == j else None for j in range(num_vertices)] for i in range(num_vertices)]
    for i in range(num_vertices):
        for j in range(i+1, num_vertices):
            if random.random() < edge_density:
                weight = random.randint(*weight_range)
                graph[i][j] = graph[j][i] = weight
    return graph

def prim_mst(graph):
    num_vertices = len(graph)
    if num_vertices == 0:
        return []

    mst = []
    start_vertex = 0
    visited = set([start_vertex])
    edges = [(graph[start_vertex][j], start_vertex, j) for j in range(num_vertices) if graph[start_vertex][j] is not None]
    heapq.heapify(edges)

    while len(visited) < num_vertices and edges:
        weight, frm, to = heapq.heappop(edges)
        if to not in visited:
            visited.add(to)
            mst.append((frm, to, weight))
            for next_vertex in range(num_vertices):
                if next_vertex not in visited and graph[to][next_vertex] is not None:
                    heapq.heappush(edges, (graph[to][next_vertex], to, next_vertex))

    return mst
num_vertices=0
def kruskal_mst(graph):
    num_vertices = len(graph)
    edges = []

    for i in range(num_vertices):
        for j in range(i + 1, num_vertices):
            if graph[i][j] is not None:
                edges.append((graph[i][j], i, j))

    edges.sort(key=lambda x: x[0])
    ds = DisjointSet(range(num_vertices))
    mst = []

    for weight, start, end in edges:
        if ds.find(start) != ds.find(end):
            ds.union(start, end)
            mst.append((start, end, weight))

    return mst

def measure_time(num_vertices, density, min_weight, max_weight, repetitions=5):
    graph = generate_graph_negative(num_vertices, density, (min_weight, max_weight))
    total_prim_time = 0
    total_kruskal_time = 0

    for _ in range(repetitions):
        start_time = time.perf_counter()
        prim_mst(graph)
        total_prim_time += time.perf_counter() - start_time

        start_time = time.perf_counter()
        kruskal_mst(graph)
        total_kruskal_time += time.perf_counter() - start_time

    avg_prim_time = total_prim_time / repetitions
    avg_kruskal_time = total_kruskal_time / repetitions

    return avg_prim_time, avg_kruskal_time

def running_time_comparison1(density, min_weight, max_weight, repetitions=5):
    graph_sizes = [i for i in range(10, 500, 20)]  # Increase graph sizes for better visibility of time differences
    prims_times = []
    kruskals_times = []

    for size in graph_sizes:
        running_time = measure_time(size, density, min_weight, max_weight, repetitions)
        prims_times.append(running_time[0])
        kruskals_times.append(running_time[1])
        print(f"Graph Size: {size}, Prim's Avg Time: {running_time[0]}, Kruskal's Avg Time:{running_time[1]}")

    plt.figure(figsize=(10, 6))
    plt.plot(graph_sizes, prims_times, label='Prim\'s Algorithm', marker='o')
    plt.plot(graph_sizes, kruskals_times, label='Kruskal\'s Algorithm', marker='x')
    plt.xlabel('Graph Size (Number of Vertices)')
    plt.ylabel('Average Running Time (Seconds)')
    plt.title('Comparison of Average Running Times: Prim\'s vs Kruskal\'s Algorithm')
    plt.legend()
    plt.show()

running_time_comparison1(0.9,-10,15)