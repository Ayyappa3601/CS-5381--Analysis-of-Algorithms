import heapq

def prim_mst(graph):
    """
    Computes the minimum spanning tree (MST) of a graph using Prim's algorithm.

    Parameters:
    graph (list of lists): A graph represented as an adjacency matrix where
                           graph[i][j] represents the weight of the edge between
                           vertices i and j. If there's no edge, it's represented
                           by None.

    Returns:
    list of tuples: The MST represented as a list of tuples (start_vertex, end_vertex, weight).
    """
    num_vertices = len(graph)  # Number of vertices in the graph
    if num_vertices == 0:
        return []

    mst = []  # Initialize the list to store the edges of the MST
    start_vertex = 0  # Start the algorithm from the first vertex (index 0)
    visited = set([start_vertex])  # A set to keep track of visited vertices

    # Initialize a priority queue (min heap) to store edges with their weights
    # Only include edges that are present (graph[start_vertex][j] is not None)
    edges = [(graph[start_vertex][j], start_vertex, j) for j in range(num_vertices) if graph[start_vertex][j] is not None]
    heapq.heapify(edges)

    # Main loop to construct the MST
    while len(visited) < num_vertices and edges:
        weight, frm, to = heapq.heappop(edges)  # Select the edge with the minimum weight
        if to not in visited:
            visited.add(to)  # Mark the vertex as visited
            mst.append((frm, to, weight))  # Add the edge to the MST

            # Add new edges to the priority queue from the newly added vertex
            for next_vertex in range(num_vertices):
                if next_vertex not in visited and graph[to][next_vertex] is not None:
                    heapq.heappush(edges, (graph[to][next_vertex], to, next_vertex))

    return mst

# Dense Graph with 14 nodes (more edges, closer to a complete graph):
dense_graph = [
    # Input of a dense graph represented as an adjacency matrix
    # Nodes have connections with many other nodes (more edges compared to nodes)

    [None, 5, 9, 2, 4, 1, 6, 7, 10, 8, 12, 3, 2, 4],  
    [5, None, 3, 6, 7, 9, 8, 10, 2, 11, 5, 4, 2, 5],  
    [9, 3, None, 1, 5, 8, 9, 4, 6, 7, 3, 5, 7, 1],  
    [2, 6, 1, None, 9, 7, 5, 3, 4, 6, 2, 8, 1, 7],  
    [4, 7, 5, 9, None, 6, 4, 2, 3, 5, 9, 7, 3, 6],  
    [1, 9, 8, 7, 6, None, 2, 5, 7, 8, 4, 6, 9, 1],  
    [6, 8, 9, 5, 4, 2, None, 1, 3, 2, 9, 7, 8, 3],  
    [7, 10, 4, 3, 2, 5, 1, None, 6, 4, 5, 3, 2, 9],  
    [10, 2, 6, 4, 3, 7, 3, 6, None, 1, 8, 2, 4, 5],  
    [8, 11, 7, 6, 5, 8, 2, 4, 1, None, 7, 6, 3, 2],  
    [12, 5, 3, 2, 9, 4, 9, 5, 8, 7, None, 1, 6, 4],  
    [3, 4, 5, 8, 7, 6, 7, 3, 2, 6, 1, None, 5, 8],  
    [2, 2, 7, 1, 3, 9, 8, 2, 4, 3, 6, 5, None, 7],  
    [4, 5, 1, 7, 6, 1, 3, 9, 5, 2, 4, 8, 7, None]   
]



#computing and calculating the total weight of the minimum spanning tree
minimum_spanning_tree = prim_mst(dense_graph)
total_weight = sum(edge[2] for edge in minimum_spanning_tree)
print("Total weight of minimum spannning tree:", total_weight)
print("Minimum spanning tree for prim_mst(dense_graph):", minimum_spanning_tree)


