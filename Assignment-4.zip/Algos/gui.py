#importing the necessary libraries
import tkinter as tk
import networkx as nx
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt

#Function to draw the graph based on the input data
def draw_graph():
    ax.clear()  # Clear the previous graph

    # Parse the input data to create a graph and split into lines
    graph_data = input_field.get("1.0", "end-1c").splitlines()
    G = nx.Graph() #intializing to a new graph object
    #Iterate over the input data to add edges to the graph
    print(graph_data,G)
    for edge in graph_data:
        node1, node2, weight = edge.split() #split each line to parts
        G.add_edge(node1, node2, weight=float(weight)) #Add edges to the graph with weights
    print(G)
    # Draw the graph using a spring layout
    pos = nx.spring_layout(G)
    nx.draw(G, pos, ax=ax, with_labels=True, font_weight='bold')
    #get the edge labels for weights and draw them
    edge_labels = nx.get_edge_attributes(G, 'weight')
    nx.draw_networkx_edge_labels(G, pos, edge_labels=edge_labels)

    canvas.draw() #update the canvas with the new graph

#function to display prim's minimum spanning tree
def show_prim_mst():
    ax.clear()  # Clear the previous graph 

    # Parse the input data to create a graph
    graph_data = input_field.get("1.0", "end-1c").splitlines()
    print(graph_data)
    G = nx.Graph()
    for edge in graph_data:
        node1, node2, weight = edge.split()
        G.add_edge(node1, node2, weight=float(weight))
    print(G)
    # Calculate the MST
    mst = nx.minimum_spanning_tree(G,algorithm="prim")

    # Draw the MST
    pos = nx.spring_layout(mst)
    nx.draw(mst, pos, ax=ax, with_labels=True, font_weight='bold',node_color="#AEC6CF")
    edge_labels = nx.get_edge_attributes(mst, 'weight')
    nx.draw_networkx_edge_labels(mst, pos, edge_labels=edge_labels)

    canvas.draw() #update the canvas with minimum spanning tree

#function to display the kruskal's minimum spanning tree
def show_kruskal_mst():
    ax.clear()  # Clear the previous graph

    # Parse the input data to create a graph
    graph_data = input_field.get("1.0", "end-1c").splitlines()
    print(graph_data)
    G = nx.Graph()
    for edge in graph_data:
        node1, node2, weight = edge.split()
        G.add_edge(node1, node2, weight=float(weight))
    print(G)
    #calculate the minimum spanning tree
    mst = nx.minimum_spanning_tree(G,algorithm="kruskal")

    # Draw the MST
    pos = nx.spring_layout(mst)
    nx.draw(mst, pos, ax=ax, with_labels=True, font_weight='bold',node_color="#AC94F4")
    edge_labels = nx.get_edge_attributes(mst, 'weight')
    nx.draw_networkx_edge_labels(mst, pos, edge_labels=edge_labels)

    canvas.draw() #update the canvas with the minimum spanning tree

# Set up the main window
root = tk.Tk()
root.title("Weighted Graph and MST Visualization")

# Create input field for graph data
input_field = tk.Text(root, height=10)
input_field.pack()

# Button to draw graph
draw_button = tk.Button(root, text="Draw Graph", command=draw_graph)
draw_button.pack()

# Button to show Prims MST
show_mst_button = tk.Button(root, text="Show Prims MST", command=show_prim_mst)
show_mst_button.pack()

# Button to show Kruskals MST
show_mst_button = tk.Button(root, text="Show Kruskals MST", command=show_kruskal_mst)
show_mst_button.pack()

# Set up the matplotlib figure and axes
fig, ax = plt.subplots()

# Embed the matplotlib figure in a Tkinter canvas
canvas = FigureCanvasTkAgg(fig, master=root)
canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=1)

# Start the Tkinter event loop
root.mainloop()